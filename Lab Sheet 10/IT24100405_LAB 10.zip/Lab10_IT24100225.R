# Exercise
observed <- c(120, 95, 85, 100)
prob <- c(.25, .25, .25, .25)

# Perform chi-squared test
chisq.test(x = observed, p = prob)